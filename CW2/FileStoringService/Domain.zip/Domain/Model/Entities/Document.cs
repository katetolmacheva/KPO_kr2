﻿using System;

namespace FileStoringService.Entities;

/// <summary>
/// Представляет документ в системе хранения файлов
/// </summary>
public class Document
{
    // Уникальный идентификатор документа
    public Guid Id { get; private set; }
    
    // Имя документа
    public string Name { get; private set; }
    
    // Путь к файлу в хранилище
    public string Path { get; private set; }
    
    // Хеш содержимого документа для проверки целостности и быстрого сравнения
    public DocumentHash Hash { get; private set; }
    
    // Дата загрузки документа
    public DateTime UploadDate { get; private set; }
    
    // Приватный конструктор для EF Core
    private Document() { }

    // Создание нового документа (фабричный метод)
    public static Document Create(string name, string path, string hashValue)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Имя документа не может быть пустым", nameof(name));
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Путь к документу не может быть пустым", nameof(path));
        if (string.IsNullOrWhiteSpace(hashValue))
            throw new ArgumentException("Хеш не может быть пустым", nameof(hashValue));

        var hash = new DocumentHash(hashValue);

        return new Document
        {
            Id = Guid.NewGuid(),
            Name = name,
            Path = path,
            Hash = hash,
            UploadDate = DateTime.UtcNow,
        };
    }
}
