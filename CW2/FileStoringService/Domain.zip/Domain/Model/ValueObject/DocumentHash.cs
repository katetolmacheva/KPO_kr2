using System;
using System.Security.Cryptography;
using System.Text;

namespace FileStoringService.Entities;

/// <summary>
/// Представляет хеш документа как Value Object
/// </summary>
public class DocumentHash
{
    public string Value { get; }

    // Конструктор для создания хеша по его значению
    public DocumentHash(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Значение хеша не может быть пустым", nameof(value));
            
        Value = value;
    }
    
    // Фабричный метод для создания хеша из содержимого
    public static DocumentHash CreateFromContent(string content)
    {
        if (string.IsNullOrEmpty(content))
            throw new ArgumentException("Содержимое не может быть пустым", nameof(content));
            
        // Создаем хеш MD5 из содержимого
        using (var md5 = MD5.Create())
        {
            byte[] contentBytes = Encoding.UTF8.GetBytes(content);
            byte[] hashBytes = md5.ComputeHash(contentBytes);
            
            // Конвертируем байты в строку в шестнадцатеричном формате
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
            {
                sb.Append(hashBytes[i].ToString("x2"));
            }
            
            return new DocumentHash(sb.ToString());
        }
    }
    
    public override bool Equals(object obj)
    {
        if (obj is not DocumentHash other)
            return false;
            
        return Value.Equals(other.Value);
    }
    
    public override int GetHashCode()
    {
        return Value.GetHashCode();
    }
    
    public static bool operator ==(DocumentHash left, DocumentHash right)
    {
        if (ReferenceEquals(left, null))
            return ReferenceEquals(right, null);
            
        return left.Equals(right);
    }
    
    public static bool operator !=(DocumentHash left, DocumentHash right)
    {
        return !(left == right);
    }
}
